export { extractPackageManagerMayorVersion } from './extract-package-json-mayor-version';
