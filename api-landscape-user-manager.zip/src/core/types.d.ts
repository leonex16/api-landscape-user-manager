export type Optional<T> = T | undefined;
