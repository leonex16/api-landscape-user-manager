export { Bcrypt as Crypto } from './bcrypt.implement';
