export { UUID as RFC4122 } from './uuid.implement';
